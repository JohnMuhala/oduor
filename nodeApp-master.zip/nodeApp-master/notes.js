var getNotes = function() {
    return "concerts are fan";
}

module.exports = getNotes;